#pragma once
#include "pch.h"
#include <cstdio>
#include <string>
#include <map>

#define DEFAULT_CACHE_SIZE 100*1024; // 100 kB

class FileCache {
public:
	FileCache(FILE* handle);
	~FileCache();
	size_t Save(size_t pos, size_t length, unsigned char* data);
	unsigned char* Load(size_t pos);
	size_t SaveCacheToFile();
	bool HasData();
	bool HasError();
private:
	FILE* handle;
	int GetFileSize();
	bool hasData = false;
	bool hasError = false;
	unsigned char* cache;
	size_t cacheSize;
	int fileSize;
};

class Cache {
public:
	FileCache* GetCache(FILE* handle);
	bool SaveRemoveCache(FILE* handle);
	bool RemoveCache(FILE* handle);
	size_t RemoveAll();
private:
	std::map<FILE*, FileCache*> cacheMap;
};
