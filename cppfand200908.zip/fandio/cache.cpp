#include "pch.h"
#include "cache.h"

FileCache::FileCache(FILE* handle)
{
	this->handle = handle;
	fileSize = GetFileSize();
	if (fileSize >= 0)	{
		cacheSize = fileSize;
		if (this->fileSize == 0) cacheSize = DEFAULT_CACHE_SIZE; // soubor je prazdy, vytvorime cache o vychozi velikosti
		cache = new unsigned char[cacheSize] {0};
		fseek(handle, 0, SEEK_SET);
		size_t loaded = fread_s(cache, cacheSize, 1, fileSize, handle);
		hasData = true;
	}
	else {
		// nepodarilo se zjistit velikost souboru, mozna je uzavreny
		fileSize = 0;
		cacheSize = 0;
		hasError = true;
	}
}

FileCache::~FileCache()
{
	if (cacheSize > 0) delete[] cache;
}

size_t FileCache::Save(size_t pos, size_t length, unsigned char* data)
{
	// vlezou se data do cache?
	if (pos + length <= cacheSize) {
		memcpy(&cache[pos], data, length);
		return length;
	}
	// nevlezou, vytvorime novou, rozsirenou
	size_t newSize = pos + length;
	auto newCache = new unsigned char[newSize];
	// zkopirujeme do ni puvodni cache, kterou pak smazeme
	memcpy(newCache, cache, cacheSize);
	if (cacheSize > 0) delete[] cache;
	// pridame k ni nova data
	memcpy(&newCache[pos], data, length);
	// nastavemi objekt
	cacheSize = newSize;
	cache = newCache;
	return length;
}

unsigned char* FileCache::Load(size_t pos)
{
	if (pos >= cacheSize) return nullptr;
	return &cache[pos];
}

size_t FileCache::SaveCacheToFile()
{
	fseek(handle, 0, SEEK_SET);
	size_t wrote = fwrite(cache, 1, cacheSize, handle);
	return wrote;
}

bool FileCache::HasData()
{
	return hasData;
}

int FileCache::GetFileSize()
{
	//long oldPos = ftell(handle);
	if (fseek(handle, 0, SEEK_END) != 0) {
		return -1;
	}
	long fileSize = ftell(handle);
	//fseek(handle, oldPos, SEEK_SET);
	return fileSize;
}

FileCache* Cache::GetCache(FILE* handle)
{
	std::map<FILE*, FileCache*>::iterator it = cacheMap.find(handle);
	if (it == cacheMap.end()) {
		// cache zatim v mape neexistuje, zalozime ji
		FileCache* c = new FileCache(handle);
		cacheMap.insert(std::pair<FILE*, FileCache*>(handle, c));
		return c;
	}
	return it->second;
}

bool Cache::SaveRemoveCache(FILE* handle)
{
	std::map<FILE*, FileCache*>::iterator it = cacheMap.find(handle);
	if (it == cacheMap.end()) return false;
	it->second->SaveCacheToFile();
	delete it->second;
	cacheMap.erase(it);
	return true;
}

bool Cache::RemoveCache(FILE* handle)
{
	std::map<FILE*, FileCache*>::iterator it = cacheMap.find(handle);
	if (it == cacheMap.end()) return false;
	delete it->second;
	cacheMap.erase(it);
	return true;
}

size_t Cache::RemoveAll()
{
	size_t count = 0;
	for (auto& c : cacheMap)
	{
		delete c.second;
		count++;
	}
	cacheMap.clear();
	return count;
}
