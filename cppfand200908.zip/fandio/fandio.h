#pragma once

#if (ODBCVER < 0x200)
#define	SQL_NO_TOTAL	-4
#endif

#define MAXPAGESIZE 1024
#define XPAGESIZE 512
#define MAXKEYSIZE	256
#define MAXLSTRLEN 65000u  

enum lk_modes
{
	LK_NOEXCL, LK_NODEL, LK_NOCR, LK_RD, LK_WR, LK_CR, LK_DEL, LK_EXCL
};

class CTFile {
public:
	//	enum OpenMode {Old,New,OldNew,Overwrite};
	//	enum UseMode  {Exclusive,RdOnly,RdShared,Shared};
	//	enum LockMode {NullMode,RdMode,WrMode,CrMode,DelMode,ExclMode};             
	bool updated;
	CTFile(const char* aPath);
	~CTFile();
	virtual bool Open(int mode);
	void Close();
	virtual bool ReadPfx();
	virtual void WritePfx();
	virtual void Flush();
	virtual void UnFlush();
	int error();
	void Seek(long pos);
	long lSeek(long, int);
	//	bool	Locking(unsigned short);
	bool Locking(bool, long, long);
	unsigned short Read(void* buf, unsigned short sz);
	void Write(void* buf, unsigned short sz);
	void Trunc(long sz);
	long Tell();
	long GetSize();
	bool Create();
	bool Erase();
	bool Rename(char* newPath);
	// bool ChangeLMode(LockMode mode);
	// bool TryLMode(LockMode mode);
	void OldLMode();
	void ErrMsg(unsigned short n);
	void Error(unsigned short n);
	void TestHError();
	//private:
	char* path; 
	int handle;
	// UseMode uMode; bool netFile; LockMode lMode;   
	// bool TryLock(long pos,unsigned short sz);
	// void UnLock(long pos,unsigned short sz);
};

class TFFile : public CTFile
{
public:
	long recs;
	unsigned short recsz;
	char idx;

	TFFile(const char* aPath);
	~TFFile();
	bool ReadPfx(int);
	void WritePfx();
	int ReadRec(void*);
	void WriteRec(void*);
};

class TPFile : public CTFile
{
protected:
	long freeRoot, eofPos, freePart;
	short pagesize;
	// long NewZeroPg();

public:
	TPFile(const char* aPath);
	// ~TPFile();	
	bool Open(int mode);
	void ReadPg(long, void*);
	void WritePg(long, void*);
	virtual long NewPg();
	virtual void ReleasePg(long pos);
};

class THFile : public TPFile {
protected:
	//	union
	//	{
	struct { long startPos, segPos, workPos; };	// StoreStr()
	struct { unsigned short size, length, rest; };	// ReadStr()
	long rdPos;
	//	};
	void AddLongStr(char*, size_t, unsigned short);
	void StoreShortStr(char*, size_t);

public:
	THFile(const char* aPath);
	~THFile();
	bool Create();
	// virtual void Close();
	bool ReadPfx();
	void WritePfx();
	bool ReadStr(long pos);
	char* ReadStrData(char*, size_t, long*);
	void StoreStr();
	long StoreStr(char*, size_t);
	void DeleteStr(long pos);
};

typedef char Bool;

class TXFile;

#define	CACHE_UPDATED	1			// TXBuf flag
#define CACHE_USED		2           // TXBuf flag

struct TXBuf                		// index page cache buffer
{
	TXBuf* chain;
	long addr;
	short len;
	char flag;		// updated, used (obecneji citac)
	unsigned char data[1];
};

class TXPage
{
public:
	TXBuf* buf;			// adresa bufferu
	unsigned char* first;			// 1. item  
	unsigned char* item;			// address of actual item
	long gPage;
	short off;			// item header size
	short hdr;			// page header size
	Bool isLeaf;
	unsigned char nItems;
	short pagesize;
	//    char 	data[XPAGESIZE];         // zacatek fyzicke diskove stranky                  

	TXPage(short);
	~TXPage();
	unsigned char* M();
	unsigned char* L();
	long getN();
	void putN(long);
	long getD();
	void putD(long);
	// long getG();
	// void putG(long);
	unsigned char* nextItem();
	//BYTE*	nItems();
	void swapAddr(TXPage*);

	long getDownPg(int);
	// void InitPg(int);
	int	Balance(TXPage*, unsigned char*, size_t&);
	// int Off();
	// unsigned short EndOff();
	// bool Underflow();
	// bool Overflow();            
	unsigned char* XI(int i);
	void StrI(int, unsigned char*, size_t&);
	long SumN();
	long Insert(int i, unsigned char*, size_t&, TXFile*, long, long);
	void InsDownIndex(int i, long page, TXPage* p);
	bool Delete(int i);
	// void AddPg(TXPage *p);  
	void SplitPg(TXPage* p, long thisPage);
};

class TXFile : public TPFile
{
	struct TXPath { long page; int i; };
	TXBuf* cache;
	short buffers, maxbuffers;
	short signum;
	char NrKeys;
	TXPath xPath[10]; 
	int xPathN;

	// long NewZeroPg(TXPage *);          
	// PXItem InsertItem(PString s,TXPage *p,TXPage *upP,long page,int i,long& upPage);
	void InsertItem(TXPage*, int, unsigned char*, size_t, long, long, int);
	bool IncPath(TXPage*);
	bool DecPath(TXPage*);
	bool StrNrToPath(short, unsigned char*, size_t, long, TXPage*);
	void ChainPrevLeaf(TXPage* p, long n);
	bool BalancePages(TXPage* p1, TXPage* p2);
	void XIDown(TXPage* p, TXPage* p1, int i, long& page1);
	bool inCache(long, TXBuf**);
	bool NrToPath(short, long, TXPage*);
public:
	long NRecs;
	long NRecsAbs;

	TXFile(const char* aPath, int);
	~TXFile();
	bool Create(short, int);
	bool ReadPfx();
	void WritePfx();
	void ReadXPg(long, TXPage*);
	void WriteXPg(long, TXPage*);
	long NewXPg(TXPage*);
	void ReleaseXPg(TXPage*);
	bool SearchX(short, unsigned char*, size_t, bool, long&);
	bool Searchx(short, unsigned char*, size_t, bool, long&, TXPage*);
	void InsertX(short, unsigned char*, size_t, long);
	bool DeleteX(short, unsigned char*, size_t, long);
	void FlushX(bool);
	void DeleteIndex(long rootPg);
	void InitPg(TXPage*);
	long NextX();
	long PrevX();
	long ReadX(short, long);
};

#pragma pack(1)

struct f_pfx
{
	long	recs;
	unsigned short recsz;
};

struct h_pfx
{
	short signum;				// 0x0001
	short OldMaxPage;
	long FreePart;
	char Reserved;
	char CompileProc;
	char CompileAll;
	short IRec;
	long FreeRoot;
	long MaxPage;
};

union x_pfx
{
	struct
	{
		short signum;			// 0x02ff
		short FreeRoot;
		short MaxPage;
		long NRecs;
		long NRecsAbs;
		char NotValid;
		char NrKeys;
	} s2;
	struct
	{
		short signum;			// 0x03ff
		long FreeRoot;
		long MaxPage;
		long NRecs;
		long NRecsAbs;
		char NotValid;
		char NrKeys;
	} s3;
};

#pragma pack()
