#include "pch.h"
#include "fandio.h"

#include <windows.h>
#include <string>
#include <stdlib.h>
#include <stdio.h>
#include <io.h>
#include <fcntl.h>
#include <sys/locking.h>
#include "fandio.h"

/////////////////////////////////////////////////////////////////////////////////////////

unsigned short equChars(unsigned char* s1, size_t l1, unsigned char* s2, size_t l2)
{
	unsigned short i, l;

	l = l1 > l2 ? l2 : l1; 		// min(l1, l2);
	for (i = 0; i < l; i++)
		if (*s1++ != *s2++)
			break;
	return(i);
}

/////////////////////////////////////////////////////////////////////////////////////////


CTFile::CTFile(const char* pathName)
{
	path = pathName ? _strdup(pathName) : nullptr;	// zapamatuju si to (rename, remove)
}

CTFile::~CTFile()
{
	free(path);
	_lclose(handle);
}

void CTFile::Close()
{
	_lclose(handle);
}

bool CTFile::Open(int mode)
{
	handle = _lopen(path, mode);
	return handle != -1;
}

int CTFile::error()
{
	return GetLastError();
}

unsigned short CTFile::Read(void* buf, unsigned short sz)
{
	return(_lread(handle, buf, sz));
}

void CTFile::Write(void* buf, unsigned short sz)
{
	if (sz == 0)			// abych neudelal truncate !!
		return;
	_lwrite(handle, (const char*)buf, sz);
	updated = true;
}

void CTFile::Error(unsigned short n) {
}

void CTFile::ErrMsg(unsigned short n) {
}

void CTFile::Trunc(long sz) 				// nastaveni na zadanou delku (i prodlouzeni)
{
	Seek(sz);
	// C File Handling routines: int chsize(int handle, long size)
	_lwrite(handle, (const char*)nullptr, 0);
	updated = true;
}

void CTFile::Flush()
{
}

void CTFile::UnFlush()
{
	ReadPfx();
}

long CTFile::lSeek(long pos, int orig)
{
	return(_llseek(handle, pos, orig));			// SEEK_SET
}

void CTFile::Seek(long pos)
{
	lSeek(pos, 0);
}

long CTFile::Tell()
{
	return(lSeek(0, 1));	// SEEK_CUR
}

long CTFile::GetSize()                 // C File Handling routines: long filelength(handle)
{
	long pos, sz;
	pos = lSeek(0, 1); 	// SEEK_CUR (save current position)
	sz = lSeek(0, 2); 	// SEEK_END
	Seek(pos); 						// obnov puvodni pozici
	return(sz);
}

bool CTFile::Create()
{
	return((handle = _lcreat(path, 0)) != -1);
}

bool CTFile::Erase()
{
	return(!remove(path));
}

bool CTFile::Rename(char* newPath)
{
	if (rename(path, newPath) != 0)
		return(false);
	free(path); 				// free old name
	path = _strdup(newPath);
	return(true);
}

bool CTFile::ReadPfx()
{
	return(true);
}

void CTFile::WritePfx()
{
}

bool CTFile::Locking(bool lock, long offset, long size)
{
	if (lock)
		return LockFile((HANDLE)handle, offset, 0, size, 0);
	else
		return UnlockFile((HANDLE)handle, offset, 0, size, 0);
}

////////////////////////////////////////////////////////////////////////////////////////////

TPFile::TPFile(const char* aPath) : CTFile(aPath)
{
}

//TPFile::~TPFile() 
//{
//}

bool TPFile::Open(int mode)
{
	if (CTFile::Open(mode))
		return(ReadPfx());
	return(false);
}

void TPFile::ReadPg(long pos, void* p)
{
	Seek(pos);
	Read(p, pagesize);
}

void TPFile::WritePg(long pos, void* p)
{
	Seek(pos);
	Write(p, pagesize);
}

long TPFile::NewPg()
{
	long pos;

	if (freeRoot)               // volna stranka uvnitr souboru?
	{
		Seek(pos = freeRoot);   // ANO, vezmu 1. ze seznamu
		Read(&freeRoot, 4);     // dalsi volna stranka
		freeRoot *= pagesize;
	}
	else
	{
		pos = eofPos;			// NE
		eofPos += pagesize;		// prodlouzim soubor o logickou stranku
		Trunc(eofPos);			// kvuli FANDu i o fyzickou
	}
	return(pos);
}

void TPFile::ReleasePg(long pos)
{
	long l;

	if (pos == (eofPos - pagesize))		// je-li to posledni stranka souboru
		Trunc(eofPos = pos);			// tak zkratim soubor
	else
	{
		Seek(pos);
		l = freeRoot / pagesize;
		Write(&l, 4);					// uvolnovanou stranku dam do seznamu volnych
		freeRoot = pos;
	}
}


////////////////////////////////////////////////////////////////////////////////////////////

THFile::THFile(const char* aPath) : TPFile(aPath)
{
	//	char buf[XPAGESIZE];
	//	long fs;

	/*	if ((fs = GetSize()) < XPAGESIZE)
		{
			// vybuduju zahlavi union??
			freeRoot = 0;
			eofPos = XPAGESIZE;
			freePart = 512;
			memset(buf, 0, XPAGESIZE);
			WritePg(0, buf);
		}
	*/
}

THFile::~THFile()
{
	//	if (updated) 
	//		WritePfx(); 
}

bool THFile::ReadPfx()
{
	h_pfx p;

	Seek(0);
	Read(&p, sizeof(p));          	// kontrola signum == 0x0001
	if (p.signum != 0x0001)
		return(false);
	pagesize = XPAGESIZE;			// obecne to muze zaviset na verzi souboru (signum)
	freeRoot = p.FreeRoot * XPAGESIZE;			// tyto 2 udaje slouzi pro strankovani	
	eofPos = (p.MaxPage + 1) * XPAGESIZE;
	freePart = p.FreePart;			// aktualni stranka s kratkymi texty
	return(true);
}

void THFile::WritePfx()
{
	h_pfx p;

	p.signum = 1;   		// zahlavi ve strukture, nebo to nacitat???
	p.OldMaxPage = -1;
	p.FreePart = freePart;
	p.FreeRoot = freeRoot / XPAGESIZE;
	p.MaxPage = eofPos / XPAGESIZE - 1;
	Seek(0);
	Write(&p, sizeof(p));
}


bool THFile::ReadStr(long pos)
{
	if (pos < XPAGESIZE || pos >= eofPos)
		return(false);
	Seek(pos);
	Read(&size, 2);				// nactu delku 1. segmentu
	if (size == MAXLSTRLEN + 1)
		length = MAXLSTRLEN;
	else
		length = size;
	rest = (length > XPAGESIZE - 2) ? XPAGESIZE - 6 : length;
	rdPos = pos + 2;
	return(true);
}

char* THFile::ReadStrData(char* s, size_t l, long* ls)
{
	long l1;
	unsigned short i;
	char* p = s;

	Seek(rdPos);
	*ls = length;						// kolik je k dispozici v beznem segmentu
	//l--;							// misto pro \0
	while (!0)
	{
		if (rest == 0)				// neni nastaveny sektor
		{
			if (length == 0)		// vycerpan segment?
			{
				if (size != MAXLSTRLEN + 1)	// je dalsi segment?
					break;					// ne
				l1 = Tell();			// nastavit 4 slabiky pred konec bezne stranky
				//l1 = l1 - l1 % XPAGESIZE + XPAGESIZE - 4;
				//Seek(l1);
				Seek(l1 + 22);		// misto predchozich 2 instrukci

				Read(&l1, 4);		// pointr na dalsi segment
				ReadStr(l1);
				*ls += length;		// pokusim se vratit delku co nejdrive
			}
			else
			{
				Read(&l1, 4); 		// handle ukazuje na link na konci sektoru
				Seek(l1);			// handle nastavim na dalsi sektor
				rest = (length > XPAGESIZE) ? XPAGESIZE - 4 : length;
			}
		}
		i = (l < rest) ? l : rest;
		Read(p, i);
		p += i;
		l -= i;
		rest -= i;			// zbytek v sektoru
		length -= i;		// zbytek v segmentu
		if (l == 0)  		// zaplneno destination
			break;
	}
	//*p = '\0';
	if (size == MAXLSTRLEN + 1)
		*ls = SQL_NO_TOTAL;			// SQL_NO_TOTAL, neni k dispozici potrebna delka
	rdPos = Tell();
	return(s);
}

void THFile::StoreShortStr(char* s, size_t l)
{                  			// tohle zobecnit na hledani ve strance?
	short i;

	//	Seek(freePart);
	//	Read(&i, 2);			
	//	i = -i; 				// delka volne casti pro data
	i = pagesize - freePart % pagesize - 2;		// delka volne casti - 2 = prostor pro text
	if (l > (unsigned short)i)	// vejde se tam?
	{
		// mohl by prohledavat volne casti
		freePart = NewPg(); 	// ne, alokuju novou stranku
		i = XPAGESIZE - 2;		// prostor pro data
	}
	Seek(startPos = freePart);
	Write(&l, 2);			// zapisu delku
	Write(s, l);			// zapisu data
	i -= l;
	// nepripravovat novou stranku (?) - je to predcasne
	// problem - pri uplnem vycerpani ukazuje na nasledujici stranku
	// mohl by mirit o byte nize, stejne se tam zadny fragment nevejde
	// pri ruseni to odchytnu na posledni segment a ne free
	if (i < 2)				// pripravim novou stranku
	{
		freePart = NewPg();
		Seek(freePart);
		i = -XPAGESIZE;
	}
	else
	{
		freePart += l + 2;
		i = -i;
	}
	i += 2;
	Write(&i, 2);
}

void THFile::AddLongStr(char* s, size_t l, unsigned short ls)
{
	long l1, pos;
	unsigned short i, u;
	char* p;

	while (!0)				// segment loop
	{
		l1 = ls + l;            	// nova delka
		if (l1 > MAXLSTRLEN)        // vysledek delsi nez segment?
		{
			u = MAXLSTRLEN - ls;	// kolik se vejde do stavajiciho segmentu
			l1 = MAXLSTRLEN + 1;	// ano
		}
		else
			u = l;
		l -= u;					// kolik zbyva na dalsi segment
		Seek(segPos);
		Write(&l1, 2);				// INTEL!
		if (i = workPos % XPAGESIZE)		// nikdy nepripravuju prazdnou stranku!
			i = XPAGESIZE - i;              // volne misto ve strance
		if (u > i && i < 4)		// nevejde se a neni misto na adresu, musim ho uvolnit
		{
			workPos += (short)i - 4;	// couvnu na 4 slabiku pred koncem stranky
			Seek(workPos); Read(&l1, 4);	// uschovam 4 posledni slabiky
			pos = NewPg();
			Seek(workPos); Write(&pos, 4);
			Seek(pos); Write(&l1, 4);		// na zacatek nove stranky ulozim uschovana data
			workPos = pos + 4 - i;
			i = XPAGESIZE + (short)i - 4;        // volne misto v nove strance
		}
		for (p = s; u > i; u -= i, p += i, workPos = pos, i = XPAGESIZE)	// dokud se to nevejde  cele
		{
			i -= 4;			// vynecham misto na chain adresu (musi byt zaruceno)
			pos = NewPg();
			Seek(workPos);
			Write(p, i);
			Write(&pos, 4);	// zapisu chain addresu
		}
		Seek(workPos);		// zapisu zbytek segmentu
		Write(p, u);
		workPos += u;
		if (l == 0)			// neni treba dalsi segment
			break;
		s = p + u;
		segPos = NewPg();
		workPos = workPos - workPos % XPAGESIZE + XPAGESIZE - 4;  // muze to byt za strankou???
		Seek(workPos);
		Write(&segPos, 4);
		workPos = segPos + 2;
		ls = 0;
	}
}

void THFile::StoreStr()
{
	segPos = startPos = 0;		// zahajim ukladani
}

long THFile::StoreStr(char* s, size_t l)
{
	long l1;
	short i;
	char buf[XPAGESIZE];

	if (startPos != 0)			// rozpracovano?
	{       				// ANO
		if (segPos != 0)		// long string?
			Seek(segPos);		// ano
		else
			Seek(startPos);     // ne
		Read(&i, 2);			// dosud zapsana delka v aktualnim segmentu
		l1 = (unsigned short)i + l; 			// nova delka
		if (segPos == 0 && ((unsigned short)i < XPAGESIZE - 2))		// short data?
		{
			Read(buf, i);
			DeleteStr(startPos);
			if (l1 < XPAGESIZE - 2)	// zustane short string
			{   	// pripad zapisu kratkych stringu po castech je blbost, neoptimalizuju!
				memmove(buf + i, s, l);		// v bufferu vytvorim novy short string
				StoreShortStr(buf, l + i);
			}
			else						// vytvorim long string
			{
				segPos = startPos = NewPg();
				Seek(startPos + 2);
				Write(buf, i);				// zapisu puvodni data
				workPos = startPos + i + 2;
				AddLongStr(s, l, i);
			}
		}
		else						// pridavat k long stringu
			AddLongStr(s, l, i);
	}
	else						// NE     -- odpovida soucasnemu reseni
	{
		if (l < XPAGESIZE - 2)		// short string?
		{
			StoreShortStr(s, l);
		}
		else						// long string
		{
			segPos = startPos = NewPg();
			workPos = startPos + 2;
			AddLongStr(s, l, 0);
		}
	}
	return(startPos);
}

void THFile::DeleteStr(long pos)
{
	long pospg;
	short l;
	unsigned short u;
	char pg[XPAGESIZE];
	char* p, * p1;

	if (pos < XPAGESIZE || pos >= eofPos)
		return;								// mimo datovou oblast souboru
	Seek(pos); Read(&l, 2);					// delka stringu
	if ((unsigned short)l < XPAGESIZE - 2)					// short text?
	{										// ANO, short na sdilene strance
		u = (unsigned short)pos % XPAGESIZE;// offset ve strance
		pospg = pos - u;					// pozice stranky v souboru
		ReadPg(pospg, pg);					// nactu stranku
		*(short*)(pg + u) = -l;				// zaporne delku
		p = pg;
		while (!0)							// spojuji volne fragmenty (posledni je vzdy volny!)
		{
			// POZOR, fand v aktualni strance neudrzuje zbyvajici delku!!!, proto nasl. 2 radky
			if (pospg + p - pg == freePart)
				break;						// pred freePart platny string n. prazdny aktualni
			l = *(short*)p;
			if (l <= 0)						// je-li fragment volny
			{
				p1 = p - l + 2;				// adresa nasledujiciho fragmentu
				if (pospg + p1 - pg == freePart)			// volna cast aktualniho segmentu
				{
					freePart = pospg + p - pg;	// pripojim to k volne casti
					break;
				}
				if (p1 >= pg + XPAGESIZE - 2)	// byl posledni (fragment je alespon 3)
					break;
				if ((l = *(short*)p1) <= 0)	// je-li volny
					*(short*)p += l - 2;    // pripojim ho k predchozimu
				else
					p = p1;					// jinak vezmu nasledujici (nebo dalsi? + l + 2)
			}
			else
				p += l + 2;					// preskocim obsazeny fragment
		}
		//		if (freePart >= pospg && freePart < pospg + XPAGESIZE) // actual shared page?
		//		{
		//			WritePg(pospg, pg);			// zapis stranku
		//			pospg += p - pg;			// pozice posledniho volneho segmentu ve strance
		//			if (freePart > pospg)		// tohle je kvuli FANDu
		//				freePart = pospg;		// zvetsim volny prostor pro FAND
												// (lepsi by bylo mit jen adresu sdileneho segmentu)
												// (a vkladat do libovolneho fragmentu ve strance)	
		//		}
		//		else
		if (*(short*)pg <= -(XPAGESIZE - 2)	// jediny volny fragment ve strance
			&& pospg != freePart)					// a neni to aktualni segment
			ReleasePg(pospg);               // uvolnim stranku
		else
			WritePg(pospg, pg);				// zapis stranku (celou, mohlo se slucovat)
	}
	else                          	// NE, long text
		while (!0) 						// cyklus uvolnovani segmentu
		{
			u = (unsigned short)l;
			if (u == MAXLSTRLEN + 1)	// posledni segment?
				--u;                    // ano, smazu priznak
			u += 2;						// do 1. zapocitam delku
			while (!0)					// cyklus uvolnovani stranek v segmentu
			{
				Seek(pos + XPAGESIZE - 4); Read(&pospg, 4);	// nactu adresu dalsi stranky
				ReleasePg(pos);
				pos = pospg;
				if (u <= XPAGESIZE)		// posledni stranka v segmentu
					break;
				u -= XPAGESIZE - 4;
			}
			if ((unsigned short)l != MAXLSTRLEN + 1)	// dalsi segment?
				break;									// ne
			Seek(pos); Read(&l, 2);		// delka segmentu
		}
}

bool THFile::Create()
{
	short i;

	if (CTFile::Create() == false)
		return(false);
	freePart = pagesize = XPAGESIZE;
	freeRoot = 0;
	eofPos = 2 * XPAGESIZE;
	WritePfx();
	Seek(XPAGESIZE);				// je nutna 2. stranka????? lSeek(XPAGESIZE, SEEK_SET);
	i = -(short)(XPAGESIZE - sizeof(short));
	Write(&i, sizeof(short));		// zaporny pocet volnych byte
	Trunc(2 * XPAGESIZE);			// prodlouzim to na 2 stranky
	return(true);
}


/////////////////////////////////////////////////////////////////////////////////////////

#pragma check_stack(off)			// accessors -- pristup k variabilne ulozenym datum

long TXPage::getN()
{
	return(*(long*)item & 0xffffff);
}

void TXPage::putN(long l)
{
	memcpy(item, &l, 3);
}

long TXPage::getD()
{
	if (hdr == 4)
		return((long)*(short*)(item + 3) * pagesize);
	else
		return(*(long*)(item + 3) * pagesize);
}

void TXPage::putD(long l)
{
	l /= pagesize;
	if (hdr == 4)
		*(short*)(item + 3) = (unsigned short)l;
	else
		*(long*)(item + 3) = l;
}

unsigned char* TXPage::M()
{
	return(item + off);
}

unsigned char* TXPage::L()
{
	return(item + off + 1);
}

unsigned char* TXPage::nextItem()
{
	return(item += off + *L() + 2);
}

#pragma check_stack()


TXPage::TXPage(short pgsize)					// constructor
{
	pagesize = pgsize;
	buf = nullptr;						// neni pridelen buffer
}

TXPage::~TXPage()
{
	if (buf)						// je-li pridelen buffer
		buf->flag &= ~CACHE_USED;   // tak uvolnim prideleni
}

void TXPage::swapAddr(TXPage* pg)
{
	long l;

	l = pg->buf->addr;
	pg->buf->addr = buf->addr;
	buf->addr = l;
}

void TXFile::InitPg(TXPage* pg)              // musi byt naplnen isLeaf a buf
{
	switch (signum)
	{
	case 0x2ff:
		pg->hdr = 4;
		pg->off = pg->isLeaf ? 3 : 5;
		break;
	case 0x3ff:
		pg->hdr = 6;
		pg->off = pg->isLeaf ? 3 : 7;
		break;
	default:			// 0x4ff
		pg->hdr = 7;
		pg->off = pg->isLeaf ? 3 : 7;
		break;
	}
	pg->item = pg->first = pg->buf->data + pg->hdr;
}

void TXFile::ReadXPg(long pos, TXPage* pg)
{
	long l;
	TXBuf* b;

	if (b = pg->buf)
		b->flag &= ~CACHE_USED;
	if (!inCache(pos, &b))
		//  	{
		//  		Seek(pos);					// ReadPg ???  pagesize do HFile 
		//  		Read(b->data, pagesize);
		//  	}
		ReadPg(pos, b->data);
	pg->buf = b;
	// 	THFile::ReadPg(pos, p);
	pg->isLeaf = *b->data;
	InitPg(pg);           // first nezavisi na typu stranky, musi byt isLeaf
	l = (signum == 0x2ff) ? *(short*)(b->data + 1) : *(long*)(b->data + 1);
	pg->gPage = l * pagesize;
	pg->nItems = (signum != 0x4ff) ? *(pg->first - 1) : *(pg->first - 2);
}

void TXFile::WriteXPg(long pos, TXPage* pg)
{
	TXBuf* b = pg->buf;

	b->len = pagesize;			// bude parametr
	b->flag = CACHE_UPDATED;
	*b->data = pg->isLeaf;
	if (signum == 0x2ff)
		*(short*)(b->data + 1) = (unsigned short)(pg->gPage / pagesize);
	else
		*(long*)(b->data + 1) = pg->gPage / pagesize;
	if (signum != 0x4ff)
		*(pg->first - 1) = pg->nItems;
	else
		*(short*)(pg->first - 2) = pg->nItems;
	//WritePg(pos, &pg->data);
}

long TXFile::NewXPg(TXPage* pg)
{
	TXBuf* b;

	if (pg->buf)                     	// page struct mohla byt urcena pro cteni
		pg->buf->flag &= ~CACHE_USED;
	if (inCache(freeRoot, &b))
		freeRoot = *(long*)b->data * pagesize;		// nalezeno v cache
	else
		if (maxbuffers < 32767)
			b->addr = NewPg();
		else                   	// virtualni soubor jen nove (inserty)
		{
			b->addr = eofPos;
			eofPos += pagesize;
		}
	pg->buf = b;
	return(b->addr);
}

void TXFile::ReleaseXPg(TXPage* pg)
{
	TXBuf* b = pg->buf;

	//?pg->buf = nullptr;
	//?pg->first = pg->item = nullptr;    // zakazuji pristup
	b->flag = CACHE_UPDATED;		// maze priznak pouziti
	*(long*)b->data = freeRoot / pagesize;
	b->len = sizeof(long);			// delka relevantnich dat ve strance
	freeRoot = b->addr;
}

bool TXFile::inCache(long l, TXBuf** c)
{
	TXBuf* ptr, * prev, * prevc, * cand = nullptr;
	bool found = false;

	ptr = cache;						// adresa seznamu cache bufferu
	prev = prevc = nullptr;
	while (ptr)
	{
		if (!(ptr->flag & CACHE_USED))	// neni-li buffer vyhrazen
		{
			cand = ptr;					// bude kandidatem na prideleni (posledni mozna)
			prevc = prev;
		}	// else	// pouzity buffer nikdy nehledam (proto take neimplementuju citac pouziti)
		if (ptr->addr == l)				// je to pozadovana stranka?
		{
			found = true;				// ano, nalezeno
			break;
		}
		prev = ptr;
		ptr = ptr->chain;				// dalsi buffer
	}
	if (!found)
	{
		if (buffers < maxbuffers || cand == nullptr)	// neni-li vytvorena cache n. ani buffer
		{
			prevc = cand = (TXBuf*)malloc(sizeof(TXBuf) - 1 + pagesize);	// tak alokuju buffer
			++buffers;
		}
		else
			if (cand->flag & CACHE_UPDATED)		// kandidat zmenen?
			{
				// vhodna chvile pro donulovani bufferu a zapis cele stranky
				Seek(cand->addr);
				Write(cand->data, cand->len);
			}
		cand->flag = CACHE_USED;
		cand->addr = l;
	}
	if (cand != cache)			// neni-li kandidat na zacatku seznmu
	{
		prevc->chain = cand->chain;		// vyretezim kandidata
		cand->chain = cache;			// a vlozim na zacatek
		cache = cand;
	}
	*c = cand;					// vraci adresu bufferu
	return(found);				// vraci, zda bylo nalezeno v cache
}

void TXFile::FlushX(bool f)
{
	TXBuf* ptr, * ptrs;

	ptr = cache;
	while (ptrs = ptr)
	{
		if (ptr->flag& CACHE_UPDATED&& maxbuffers < 32676)
		{
			// vhodna chvile pro donulovani bufferu a zapis cele stranky
			Seek(ptr->addr);
			Write(ptr->data, ptr->len);
		}
		ptr = ptr->chain;
		if (f)      			// uvolnovat buffery?
			free(ptrs);			// ano
	}
	if (f)
		cache = nullptr;
}

unsigned char* TXPage::XI(int i)             			// preskocim i polozek
{
	for (; i > 0; i--)
		nextItem();
	return(item);
}

void TXPage::StrI(int i, unsigned char* s, size_t& l)	// buduju string od aktualniho
{                                              // l > 0
	int m;

	for (; i > 0; i--)
	{
		item += off;
		m = *item++;
		l = *item++;
		memcpy(s + m, item, l);
		item += l;
	}
	l += m;
}

long TXPage::SumN()
{
	long n;
	int i;

	if (isLeaf)
		return nItems;
	for (item = first, n = 0, i = 0; i < nItems; i++, nextItem())
		n += getN();
	return(n);
}

long TXPage::Insert(int ii, unsigned char* s, size_t& l, TXFile* f, long par1, long par2)
{
	long pageo = 0;
	unsigned char* p2 = nullptr, * p3 = nullptr, * p4 = nullptr, sn[MAXKEYSIZE], sx[MAXKEYSIZE];
	size_t l1, l2, l3, ln, lx, lr, m, n, d;
	short i, ovfl = false;
	TXPage pgo(pagesize), * x = this;

	--ii;						// od nuly
	item = first;
	if (ii < 1)				// vkladame pred prvni?
		l1 = m = 0;						// ano, nulovy prefix
	else
	{
		StrI(ii, sn, ln);		// klic predchazejici vkladane polozce
		l1 = item - first;		// StrI take nastavi item
		m = equChars(s, l, sn, ln);	// prefix vkladane polozky
	}
	l2 = off + 2 + l - m;	// delka dat vkladaneho itemu
	p2 = item;				// adresa kam vkladat

	if (ii == nItems)			// vklada se za posledni?
		l3 = 0;						// ano
	else
	{
		StrI(1, sn, ln);		// ne, klic polozky za vkladanou polozkou
		item = p2;			// znovu naadresuju polozku
		n = equChars(s, l, sn, ln);		// prefix vkladane polozky
		if ((d = n - *M()) > 0)			// prodlouzil se prefix?
		{
			item += d;             // nova adresa polozky
			memmove(item, p2, off);		// ano, zkratim polozku
			*M() = n;					// nova delka prefixu
			*L() = ln - n;				// nova delka dat
		}
		p3 = item;
		l3 = XI(nItems - ii) - p3;	// delka 2. casti, preskocim
	}
	p4 = item;

	lr = l1 + l2 + l3;			// potrebna delka pro vlozeni polozky
	if (lr <= (size_t)(pagesize - hdr))	// delka datove casti stranky indexu
	{							// vejde se to do aktualni stranky
		(nItems)++;
		if (l3 > 0)
			memmove(p2 + l2, p3, l3);	// odsunu 2. cast
	}
	else                 			// nevejde se, musim rozdelit stranku
	{
		pageo = f->NewXPg(&pgo);
		pgo.isLeaf = isLeaf;
		pgo.gPage = gPage;
		pgo.nItems = nItems;
		f->InitPg(&pgo);

		if (l1 + l2 > l2 + m + l3)		// urcim stranku, do ktere vlozim novou polozku
		{								// delim 1. cast, vkladam do nove stranky
			item = first;
			for (i = 0, n = 0; i < ii && n < lr - n + *M(); i++)
			{
				//nextItem();
				StrI(1, sn, ln);		// next item, zaroven buduju klic
				n = item - first;
			}
			pgo.nItems += -i + 1;	// pocty polozek ve strankach
			nItems = (BYTE)i;
			//			item = first;			// urcim posledni klic v 1. casti
			//			StrI(i, sn, ln);
			memcpy(sx, sn, lx = ln);
			if (i < ii)		// bude 1. cast rozdelena?
			{					// ano
				memcpy(pgo.item, item, off);	// prekopiruju zahlavi
				StrI(1, sn, ln);	// urcim klic 1. polozky v nove strance
				*pgo.M() = 0;
				*pgo.L() = ln;
				memcpy(pgo.item + off + 2, sn, ln);
				pgo.nextItem();
				if (i + 1 < ii)		// jeste tam neco je
				{
					memcpy(pgo.item, item, p2 - item);		// presunu zbytek 1. casti
					pgo.item += p2 - item;
				}
			}
			else				// ne, 2. buffer zacne vkladanou polozkou
			{
				l2 += m;
				m = 0;				// nebude mit prefix
			}
			x = &pgo;
			p2 = pgo.item;				// adresa, kam se bude vkladat
			pgo.item += l2;				// vynecham misto na vkladanou polozku
			memcpy(pgo.item, p3, l3);   // presunu 2. cast
		}
		else
		{                               // delim 2. cast, vkladam do puvodni stranky
			item = p3;
			for (i = ii, n = 0; i < nItems && l1 + l2 + n < l3 - n + *M(); i++)
			{
				nextItem();
				n = item - p3;
			}
			pgo.nItems -= (BYTE)i;
			nItems = i + 1;
			memcpy(pgo.item, item, off);
			/// muze tohle nastat?? ANO, rozlisovat tento pripad?
			if (i == ii)			// vkladame na konec 1. casti (item == p3)
			{
				memcpy(sx, s, lx = l);	// nova je posledni v 1. casti
										// v sn jiz mame klic nasledujuci
				nextItem();
			}
			else
			{
				item = p3;
				memcpy(sn, s, l);		// klic buduju od vkladaneho klice
				StrI(i - ii, sn, ln);
				memcpy(sx, sn, lx = ln);	// posledni klic v 1. casti
				StrI(1, sn, ln);            // 1. klic ve 2. casti
			}
			*pgo.M() = 0;
			*pgo.L() = ln;
			memcpy(pgo.item + off + 2, sn, ln);
			pgo.nextItem();
			memcpy(pgo.item, item, p4 - item);	// presunu zbytek
			memmove(p2 + l2, p3, n);	// udelam misto na vkladanou polozku
		}
	}
	x->item = p2;      					// vytvorim vlozenou polozku
	x->putN(par1);
	if (x->isLeaf == 0)
		x->putD(par2);
	p2 += off;
	*p2++ = m;
	*p2++ = l - m;
	memcpy(p2, s + m, l - m);			// ulozim klic
	if (pageo)
	{
		f->WriteXPg(pageo, &pgo);		// zapisu preteklou stranku
		memcpy(s, sx, lx);				// vracim klic rozdelene stranky
		l = lx;							// a jeho delku
	}
	return(pageo);
}

int TXPage::Balance(TXPage* p2, unsigned char* str, size_t& len)
{
	size_t i, m, n, l, l1, l2, lr;
	unsigned char* p, s[MAXKEYSIZE];

	item = first;
	StrI(nItems, s, l);	// klic posledni polozky 1. stranky (nastavi item)
	l1 = item - first;		// delka 2. casti

	p2->item = p2->first;
	p2->StrI(1, str, len);				// 1. klic ve 2. strance
	l2 = p2->XI(p2->nItems - 1) - p2->first;	// delka 2. casti

	m = equChars(str, len, s, l);
	lr = l1 + l2 - m;				// delka
	if (lr <= (size_t)pagesize - hdr)
	{                               // SLOUCIT
		memcpy(item, p2->first, off);	// prekopiruju zahlavi polozky
		*M() = m;
		*L() = l - m;
		memcpy(item + 2 + off, p2->first + off + 2 + m, l2 - off - 2 - m);
		nItems += p2->nItems;
		//putG(p2->getG());
		gPage = p2->gPage;
		return(1);				// released
	}
	else if (l1 > l2)
	{
		// presun z 1. stranky do 2.          this
		item = first;
		for (i = 0, n = 0; i < nItems && n < lr - n + *M(); i++)
		{
			StrI(1, str, len);	// preskoc item, zaroven buduju string
			n = item - first;
		}
		if (i == nItems)
			return(-1);			// nedoslo ke zmene
		p2->nItems += nItems - i;		// opravim pocty polozek
		nItems = i;

		if (m > 0)		// redukuju klic stare 1. polozky 2. casti
		{
			p = p2->first + m;	// polozku prefixuju
			memmove(p, p2->first, off + 2);
			p += off;
			*p++ = m;			// nova delka prefixu
			*p -= m;			// nova delka dat
		}
		memmove(p2->first + l1 - n + *M(), p2->first + m, l2 - m);	// odsunu 2. stranku

		m = *M();   					// extrahuju prefix
		memcpy(p2->first, item, off);	// vybuduju novou prvni ve 2. strance
		p = p2->first + off;
		*p++ = 0;
		*p++ = m + *L();		// delka klice nove 1.
		memcpy(p, str, m);	// vlozim prefix
		memcpy(p + m, item + off + 2, l1 - n - off - 2);// prekopiruju zbytek polozky a pripadne dalsi
	}
	else
	{
		// presun z 2. do 1.	(l1 <= l2)
		p2->item = p2->first;
		for (i = 0, n = 0; i < p2->nItems && l1 + n - m < l2 - n + *p2->M(); i++)
		{
			p2->StrI(1, str, len);	// preskoc item, zaroven buduju string
			n = p2->item - p2->first;
		}
		// muze se stat, ze nedojde ke zmene?
		p2->nItems -= (BYTE)i;
		nItems += i;

		if (m > 0)		// redukuju klic stare 1. polozky 2. casti
		{
			p = p2->first + m;	// polozku prefixuju
			memmove(p, p2->first, off + 2);
			p += off;
			*p++ = m;			// nova delka prefixu
			*p -= m;			// nova delka dat
		}
		memcpy(item, p2->first + m, n - m);		// prilep zacatek 2. stranky na konec 1. stranky

		m = *p2->M();							// extrahuju prefix
		memcpy(p2->first, p2->item, off);		// vybuduju novou prvni ve 2. strance
		p = p2->first + off;
		*p++ = 0;
		*p++ = m + *p2->L();
		memcpy(p, str, m);
		memcpy(p + m, p2->item + off + 2, l2 - n);	// dorazim zbytek 2. stranky na zacatek
	}
	return(0);
}

bool TXPage::Delete(int ii)
{
	int i;
	size_t m1, m2, l2, l3;
	unsigned char* p1, * p2;

	item = first;
	p1 = XI(ii - 1);				// adresa rusene polozky (pro vypocet delky i pro posledni)

	i = nItems - ii;				// kolik polozek ve strance zbyva za rusenou
	if (i > 0)						// neni-li posledni ve strance
	{
		m1 = *M();					// velikost prefixu rusene
		p2 = nextItem();			// adresa nasledujici polozky
		m2 = *M();					// velikost prefixu nasledujici
		l2 = *L();					// delka klice nasledujici
		l3 = XI(i) - p2;			// delka za rusenou
		if (m2 > m1)				// je nasledujici polozka prefixovana rusenou?
		{
			memcpy(p1, p2, off);	// presunu zahlavi itemu
			m2 -= m1;				// velikost pouzite casti prefixu rusene
			p1 += off + 1;			// ponecham prefix rusene
			*p1++ = l2 + m2;		// delku prodlouzim o cast prefixu pouzite z predchozi
			p1 += m2;
			p2 += off + 2;
			l3 -= off + 2;
		}
		memcpy(p1, p2, l3);
		p1 += l3;					// nova posledni adresa
	}
	--nItems;
	return(p1 - first < (pagesize - hdr) / 2);		// underflow
}

TXFile::TXFile(const char* aPath, int buffs) : TPFile(aPath)
{
	cache = nullptr;
	buffers = 0;
	maxbuffers = buffs ? buffs : 32767;
}

TXFile::~TXFile()                // slouzi jako close!!!!
{
	if (cache)  				// pokud nebylo uzavreno !!!!!!!
		FlushX(true);
}

//long TXFile::NewZeroPg(TXPage *p) {
//  long pos=NewPg();                             // prideli stranku
//  memset(p,0,sizeof(TXPage));                   // vynuluje buffer
//  return pos;
//}                                             

bool TXFile::NrToPath(short idx, long nr, TXPage* pg)
{
	long page;
	int i, j;

	page = idx * pagesize;
	for (j = 0, xPathN = 0;; j++)
	{
		xPathN++;
		xPath[j].page = page;
		ReadXPg(page, pg);
		if (pg->isLeaf)
		{
			if (nr > pg->nItems)
				return(false);
			xPath[j].i = (int)nr;
			return(true);
		}
		for (i = 0; i < pg->nItems; i++, pg->nextItem())
			if (nr > pg->getN())
				nr -= pg->getN();
			else
				break;
		xPath[j].i = i + 1;
		if (i == pg->nItems)
			page = pg->gPage;
		else
			page = pg->getD();		// down page
	}
}

long TXFile::ReadX(short idx, long nr)
{
	TXPage pg(pagesize);

	if (nr < 0)				// nebo akceptovat zaporny klic 
		nr += NRecs + 1;	// a veskerou logiku z provideru do fandio
							// NextX by zahrnul i PrevX
	if (NrToPath(idx, nr, &pg) == false)
		return(-1);
	pg.XI(xPath[xPathN - 1].i - 1);
	return(pg.getN());
}

bool TXFile::Searchx(short idx, unsigned char* str, size_t l, bool insert, long& nr, TXPage* pg)
{
	long page;
	int i, j, k, m, lp, ls, pfx;
	unsigned char* p, * s, * t;
	unsigned short iItem, items;
	char rel;
	//TXPage pg(pagesize); 

	page = idx * pagesize;
	for (j = 0, xPathN = 0;; j++)
	{
		xPathN++;
		xPath[j].page = page;
		ReadXPg(page, pg);
		items = pg->nItems;
		if (items == 0)
		{
			xPath[0].i = 1;
			return false;
		}
		iItem = 1;				// 1st item on page
		pfx = 0;				// no prefix
		rel = 1;				// priprav nerovno
		s = str;				// zacatek stringu
		ls = l;
		t = pg->item;			// priprava urychlovace
		while (iItem <= items)
		{
			p = t + pg->off;		// urychlovac p = pg.M();
			m = *p++;			// prefix length
			lp = *(t = p++);	// suffix length
			if (pfx > m)
				break;			// string je mensi nez item
			if (pfx == m)
			{
				i = (ls > lp) ? lp : ls;	// minimum delek
				for (k = 0; k < i; k++, s++, p++)	// urcim shodnou cast
					if (*(unsigned char*)s != *(unsigned char*)p)
						break;
				if (k == i)		// rovnost
				{
					//if (ls < lp)
					if (ls < lp && !insert)			// genericky mensi
						break;	// string je kratsi nez item
					else if (ls == lp && !insert)	// 1. vyhovujici
					{
						rel = 0; break;
					}
				}
				else
					if (*(unsigned char*)s < *(unsigned char*)p)
						break;	// string je mensi nez item
				pfx += k;		// nova delka shodne casti
				ls -= k;
			}
			iItem++;
			t += *t + 1;		// urychlovac pg.nextItem();
		}
		pg->item = t - pg->off - 1;	// vysledek urychlovace

		xPath[j].i = iItem;    	// uloz nalezeny item
		if (pg->isLeaf)          // koncova stranka?
		{
			if (iItem <= items)	// nalezen item?
				nr = pg->getN();           // cislo rekordu
			return(rel == 0);	// byla rovnost
		}
		if (iItem > items)
			page = pg->gPage;	//getG();	//(long)pg.greaterPage * XPAGESIZE; 
		else
			page = pg->getD();	//*(long*)(pg.item + 3) * XPAGESIZE;	// downPage
	} // for
}

bool TXFile::SearchX(short idx, unsigned char* str, size_t l, bool insert, long& nr)
{
	TXPage pg(pagesize);

	return Searchx(idx, str, l, insert, nr, &pg);	// pripadne n ignoruju
}

void TXFile::InsertItem(TXPage* pg, int jj, unsigned char* s, size_t l, long sum, long pages, int k)
{
	long page, pageo;
	int i, j;
	//TXPage pgo;
	//bool ovfl = true;

	for (j = jj; j >= 0; j--)   // cyklus ke korenu
	{
		page = xPath[j].page;
		i = xPath[j].i;                 // cislo polozky ve strance
		if (j == jj)			// poprve (z delete nemusi byt list)
			pageo = pg->Insert(i, s, l, this, sum, pages); // pro list sum == nr, pages == 0
		else                    // ne poprve
		{
			ReadXPg(page, pg);		// nactu prislusnou stranku (poprve ji mam)
			if (pageo == 0)			// nepreteklo
			{
				if (i > pg->nItems)
					return;				// neni kam propagovat
				pg->XI(i - 1);
				pg->putN(pg->getN() + k);
			}
			else
			{
				if (i <= pg->nItems)
				{
					pg->XI(i - 1);
					pg->putN(pg->getN() + k - sum);
					pg->putD(pageo);
				}
				else
					pg->gPage = pageo;	//pg->putG(pageo);
				pageo = pg->Insert(i, s, l, this, sum, pages);// propaguje ovfl
			}
		}
		if (pageo)						// stranka pretekla		
		{
			//pageo = NewPg();
			//WriteXPg(pageo, &pgo);	// zapisu preteklou stranku
			sum = pg->SumN();        		// preteklo-li, zapamatuju si atributy pro vyssi
			pages = page;
			if (pg->isLeaf)
				pg->gPage = pageo;	//pg->putG(pageo);			// retezim rozpadle listy
			else
				pg->gPage = 0;		//pg->putG(0);				// oznacim nekoncovy node
		}
		if (!pageo || j > 0)				// pretekly root zatim nezapisu
			WriteXPg(page, pg);		// zapisu stranku na disk
		if (!pageo && pg->isLeaf && pg->gPage == 0)	//pg->getG() == 0)	// URYCHLOVAC, zakladani indexu v poradi
			return;
	}
	if (pageo)				// pretekl root
	{
		TXPage pgo(pagesize);

		page = NewXPg(&pgo);
		pg->swapAddr(&pgo);
		WriteXPg(page, pg);			// puvodni root zapisu na nove misto   // page je nanic
		pgo.isLeaf = 0;
		pgo.gPage = pageo;		//pg->putG(pageo);
		pgo.nItems = 0;			/// !!!!!! (postupna nahrada predchoziho memset)
		InitPg(&pgo);
		pgo.Insert(1, s, l, this, sum, page);	// vytvorim novy root, nemuze preteci
		WriteXPg(pages, &pgo);			// a zapisu ho		// pages je nanic
	}
}

void TXFile::InsertX(short idx, unsigned char* str, size_t len, long nr)
{
	long n;//, sum, pages, pageo;
//	int i, j;
	size_t l;
	unsigned char s[MAXKEYSIZE];
	TXPage pg(pagesize);//, pgo;
//	bool ovfl;

	Searchx(idx, str, len, true, n, &pg);	// pripadne n ignoruju
//	ReadXPg(xPath[xPathN - 1].page, &pg);		///// bude to vracet search
	memcpy(s, str, l = len);			// prekopiruju klic do objektu
	InsertItem(&pg, xPathN - 1, s, l, nr, 0, 1);
	//++NRecs;
	//++NRecsAbs;
}

// viz DecPath
bool TXFile::IncPath(TXPage* p)			// nejen pro listy!!!!
{
	long page;
	int j;

	j = xPathN - 1;
	while (--j >= 0)					// cestou vzhuru hledam stranku s polozkou k dispozici
	{
		ReadXPg(xPath[j].page, p);
		if (xPath[j].i > p->nItems)		// uz jsme byli za?
			return(false);					// ano
		if (++xPath[j].i <= p->nItems)	// ve strance je dalsi polozka?
		{
			p->XI(xPath[j].i - 1);				// ano, adresa itemu
			page = p->getD();
			break;
		}
		if (p->gPage)					// posledni v dane urovni?
		{
			page = p->gPage;	//p->getG();					// ano
			break;
		}
	}
	while (!0)						// jdu dolu po 1. polozkach az k listu
	{
		xPath[++j].page = page;
		xPath[j].i = 1;
		ReadXPg(page, p);
		if (p->isLeaf)					// je to list?
			break;                      // ano
		page = p->getD();               // ne, jdu dolu
	}
	xPathN = j + 1;
	return(true);
}

bool TXFile::StrNrToPath(short idx, unsigned char* str, size_t len, long nr, TXPage* p)
{
	long n;
	int j;
	size_t ln;
	unsigned char sn[MAXKEYSIZE];

	if (!Searchx(idx, str, len, false, n, p))		// vyhledam 1. klic
		return false;							// nenalezeno
//	if (n == nr)           	// je to pozadovana veta (vzdy pri neduplicitnich klicich)
//		return(true);
	j = xPathN - 1;
	//ReadXPg(xPath[j].page, p);
// search bude dodavat stranku
	if (n == nr)           	// je to pozadovana veta (vzdy pri neduplicitnich klicich)
		return(true);
	//p->XI(xPath[j].i);		// nastavim 1. vyhovujici polozku
	// item je nastaven ze SearchX !!!!
	while (!0)           	// pro duplicitni klice hledam pozadovany rekord
	{
		while (!0)					// ve strance hledam rekord
		{
			if (p->getN() == nr)			// pozadovany rekord?
				return(true);				// ano
			if (xPath[j].i++ >= p->nItems)	// k dispozici dalsi polozka?
				break;						// ne
			p->nextItem();				// ano, naadresuju ji
			if (*p->L() != 0)				// ma jiny klic?
				return(false);
		}
		if (!IncPath(p))			// ne, cesta na dalsi stranku
			return(false);			// neni
		p->StrI(1, sn, ln);			// klic 1. polozky
		p->item = p->first;		// obnovim adresu 1. polozky
		if (!(len == ln && memcmp(str, sn, ln) == 0))	// pokracuje hledany klic?
			return(false);						// ne
		j = xPathN - 1;			// muze se menit uroven hloubky listu (NE)
	}
}

// viz take PrevX (sjednotit a rozlisovat podle znamenka indexu
// pouzit IncPath (viz DecPath v PrevX)
long TXFile::NextX()			// pouziti: po insertu a delete je treba obnovovat path
{
	int j;
	TXPage pg(pagesize);

	j = xPathN - 1;				// radeji rovnou adresu xPath[j]
	ReadXPg(xPath[j].page, &pg);
	if (xPath[j].i < pg.nItems)		// k dispozici dalsi polozka?
		pg.XI(xPath[j].i++);			// nastavim na prislusny item
	else
	{
		if ((xPath[j].page = pg.gPage) == 0)	// IncPath
			return(-1);					// neni dalsi stranka
		xPath[j].i = 1;					// zbytek cesty nemusi byt platny
		ReadXPg(xPath[j].page, &pg);	// nactu dalsi stranku
	}
	return(pg.getN());                  // vratim cislo vety			
}

bool TXFile::DecPath(TXPage* p)		// viz take IncPath
{
	long page;
	int j;

	for (j = xPathN - 1; j >= 0; j--) // jdu nahoru a hledam stranku, ktera ma
		if (xPath[j].i > 1)			// k dispozici predchozi polozku
		{
			ReadXPg(xPath[j].page, p);
			p->XI(--xPath[j].i - 1);
			while (!0)				// a jdu dolu
			{
				if (p->isLeaf)					// je to list?
				{
					xPathN = j + 1;
					return(true);
				}
				page = p->getD();
				xPath[++j].page = page;
				ReadXPg(page, p);
				p->XI((xPath[j].i = p->nItems) - 1);
			}
		}
	return false;
}

long TXFile::PrevX()
{
	TXPage pg(pagesize);

	if (DecPath(&pg))
		return(pg.getN());      // vratim cislo vety			
	return(-1);
}

long TXPage::getDownPg(int i)
{
	if (i > nItems)
		return(gPage);		//getG()); 
	else
	{
		item = first;
		XI(i - 1);
		return(getD());
	}
}

bool TXFile::DeleteX(short idx, unsigned char* str, size_t len, long nr)
{
	TXPage b1(pagesize), b2(pagesize), b3(pagesize), * pg = &b1, * p1 = &b2, * p2 = &b3, * p;
	long page, page1 = 0, page2;
	int j, i, i1, i2, rlsd, uflow;
	size_t l;
	unsigned char s[MAXKEYSIZE], * item1;

	//	page = idx * pagesize;
	if (!StrNrToPath(idx, str, len, nr, pg))		// vyhledam cestu podle stringu a duplicitu podle RecNo 
		return false;
	//--NRecs;
	memcpy(s, str, l = len);			// prekopiruju klic do objektu
	for (j = xPathN - 1; j >= 0; j--)
	{
		page = xPath[j].page;
		i = xPath[j].i;
		if (page1 == 0)			// poprve
			uflow = pg->Delete(i);	// nepodteklo a posledni list, muzu zapsat a koncit
		else
		{
			ReadXPg(page, pg);	// nactu stranku indexu
			if (!uflow)			// nepodteklo, jen aktualizuju pocty podrizenych
			{
				// WriteXPg(page1, p1);
				WriteXPg(page1, p1);	// zapisu stranku se zrusenou polozkou 
				if (i > pg->nItems)
					return true;				// jsem v posledni, muzu koncit
				pg->XI(i - 1);					// naadresuju polozku
				pg->putN(pg->getN() - 1);		// snizim pocet podrizenych
			}
			else				// podteklo, pokusim se o vyvazovani
			{
				if (i == 1)				// !!! preferovat pripojeni k nasledujici
				{
					i1 = 1;
					// p1, page1 je spodni
					ReadXPg(page2 = pg->getDownPg(i2 = 2), p2);
					item1 = pg->first;	// zapamatuju si adresu polozky
				}
				else			// vezmu predchozi
				{
					i2 = i;
					p = p1; p1 = p2; p2 = p;
					page2 = page1;
					ReadXPg(page1 = pg->getDownPg(i1 = i - 1), p1);
					item1 = pg->item;	// zapamatuju si adresu polozky
					pg->nextItem();			// naadresuju 2. polozku
				}
				rlsd = p1->Balance(p2, s, l);		// v (s, l) vraci klic 1. casti
				if (rlsd > 0 && j == 0 && pg->nItems == 1)	// pod rootem by zustala 1 polozka
				{
					// prehozeni adres jako v insert pri vzniku noveho rootu
					pg->swapAddr(p1);		// 
					ReleaseXPg(pg);
					ReleaseXPg(p2);
					WriteXPg(page, p1);		// novy root	// page je zbytecne
					return true;
				}
				WriteXPg(page1, p1);		// zapisu 1. cast na puvodni misto
				if (rlsd > 0)				// uvolneno
				{
					uflow = pg->Delete(i1);	// vyhodim polozku ukazujici na 1. stranku
					ReleaseXPg(p2);
					if (i1 > pg->nItems)	// sloucili jsme posledni
						pg->gPage = page1;	//pg->putG(page1);	// opravim item
					else
					{
						pg->item = item1;		// delete to mohl pokazit
						pg->putD(page1);
						pg->putN(p1->SumN()); // !!! pricist pocty predchozi - 1
					}
				}
				else
				{
					WriteXPg(page2, p2);			// zapis 2. cast
					if (i1 < pg->nItems)
					{
						pg->putN(p2->SumN());
						pg->item = item1;		// opet naadresuju 1. polozku
					}
					//	if (rlsd < 0)   			// balancing nezmenil klic
					//	{   
					//		pg->putN(p1->SumN());
					//		WritePg(page1, p1);
					//		uflow = false;			// stranka se nezmenila
					//	}
					//	else				// zmenil se klic
					{
						pg->Delete(i1);	// vyhodim polozku ukazujici na 1. stranku
						xPath[j].i = i1;	// page je v pohode, neprime parametry pro nasl. funkci
						InsertItem(pg, j, s, l, p1->SumN(), page1, -1);// znovu tam vlozim polozku
						return true;
					}
				}
			}
		}
		page1 = page;	// zapamatuju si stranku se zrusenou polozkou
		p = p1; p1 = pg; pg = p;
	}
	WriteXPg(page1, p1);		// zapisu root
	return true;
}

bool TXFile::ReadPfx()
{
	x_pfx p;

	Seek(0);
	Read(&p, sizeof(p));
	switch (signum = p.s2.signum)
	{
	case 0x2ff:
		if (p.s2.NotValid != 0)
			break;
		pagesize = 512;
		freeRoot = p.s2.FreeRoot * pagesize;
		eofPos = (p.s2.MaxPage + 1) * pagesize;
		NRecs = p.s2.NRecs;
		NRecsAbs = p.s2.NRecsAbs;
		NrKeys = p.s2.NrKeys;
		return(true);
	case 0x3ff:
	case 0x4ff:
		if (p.s3.NotValid != 0)
			break;
		pagesize = 1024;
		freeRoot = p.s3.FreeRoot * pagesize;
		eofPos = (p.s3.MaxPage + 1) * pagesize;
		NRecs = p.s3.NRecs;
		NRecsAbs = p.s3.NRecsAbs;
		NrKeys = p.s3.NrKeys;
		return(true);
	}
	// Not valid - vynutim vytvoreni indexu
	// Fand to nahodi napriklad po merge, aniz by ihned index vytvarel
#ifdef WIN32
	SetLastError(ERROR_FILE_NOT_FOUND);
#else
	errno = ERROR_FILE_NOT_FOUND;
#endif
	return false;
}

void TXFile::WritePfx()
{
	x_pfx p;

	switch (p.s2.signum = signum)
	{
	case 0x2ff:
		p.s2.FreeRoot = (short)(freeRoot / pagesize);
		p.s2.MaxPage = (short)(eofPos / pagesize - 1);
		p.s2.NRecs = NRecs;
		p.s2.NRecsAbs = NRecsAbs;
		p.s2.NotValid = 0;
		p.s2.NrKeys = NrKeys;
		break;
	case 0x3ff:
	case 0x4ff:
		p.s3.FreeRoot = freeRoot / pagesize;
		p.s3.MaxPage = eofPos / pagesize - 1;
		p.s3.NRecs = NRecs;
		p.s3.NRecsAbs = NRecsAbs;
		p.s3.NotValid = 0;
		p.s3.NrKeys = NrKeys;
		break;
	}
	Seek(0);
	Write(&p, sizeof(p));
}

bool TXFile::Create(short sign, int keys)
{
	int i;
	TXPage pgo(pagesize);
	long page;

	if (maxbuffers < 32767)		// realny soubor
	{
		if (CTFile::Create() == false)
			return(false);
	}

	switch (signum = sign)
	{
	case 0x2ff:
		pagesize = 512;
		break;
	case 0:
		signum = 0x4ff;		// implicitne pracuji s nejnovejsi verzi
	default:
		pagesize = 1024;
		break;
	}
	freeRoot = 0;
	NRecs = 0;
	NRecsAbs = 0;
	NrKeys = keys;
	eofPos = pagesize;

	pgo.isLeaf = 1;
	pgo.gPage = 0;
	pgo.nItems = 0;
	for (i = 0; i < keys; i++)			// vytvorim root stranky pro indexy
	{
		page = NewXPg(&pgo);
		InitPg(&pgo);
		WriteXPg(page, &pgo);
	}
	return(true);
}

//////////////////////////////////////////////////////////////////////////////////////

TFFile::TFFile(const char* aPath) : CTFile(aPath)
{
	idx = 0;
}

TFFile::~TFFile()
{
}

bool TFFile::ReadPfx(int indexes)
{
	f_pfx p;

	Seek(0);
	if (Read(&p, sizeof(p)) != sizeof(p))
		return false;
	if (p.recs < 0)
	{
		recs = -p.recs;
		idx = 1;
	}
	else
	{
		if (p.recs == 0 && indexes > 0)
			idx = 1;
		recs = p.recs;
	}
	recsz = p.recsz;
	return (indexes ? 1 : 0) == idx;
}

void TFFile::WritePfx()
{
	f_pfx p;

	p.recsz = recsz;
	p.recs = (idx == 0) ? recs : -recs;
	Seek(0);
	Write(&p, sizeof(p));
}

int TFFile::ReadRec(void* buf)
{
	unsigned short i = 0;

	if (idx)
		buf = (char*)buf - 1;		// adresa na delete flag
	if (Read(buf, recsz) != recsz)
		return 0;					// eof
	if (idx && *(char*)buf != 0)
		return -1;					// deleted
	return 1;						// platna veta
}

void TFFile::WriteRec(void* buf)
{
	if (idx)
	{
		buf = (char*)buf - 1;
		*(char*)buf = 0;		// platna veta
	}
	Write(buf, recsz);
	return;
}
