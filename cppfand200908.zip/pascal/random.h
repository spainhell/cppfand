#pragma once

extern unsigned int RandSeed;

float Random();
unsigned int Random(int Maximum);
