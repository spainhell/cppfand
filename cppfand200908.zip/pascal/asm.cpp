#include "pch.h"
#include "asm.h"

unsigned short AX = 0;
unsigned short BX = 0;
unsigned short CX = 0;
unsigned short DX = 0;
unsigned short SI = 0;
unsigned short DI = 0;
unsigned char* AL = (unsigned char*)&AX;
unsigned char* AH = (unsigned char*)&AX + 1;
unsigned char* BL = (unsigned char*)&BX;
unsigned char* BH = (unsigned char*)&BX + 1;
unsigned char* CL = (unsigned char*)&CX;
unsigned char* CH = (unsigned char*)&CX + 1;
unsigned char* DL = (unsigned char*)&DX;
unsigned char* DH = (unsigned char*)&DX + 1;

void InitR() {
	AX = 0;
	BX = 0;
	CX = 0;
	DX = 0;
	SI = 0;
	DI = 0;
}

int cmpstr(unsigned char* a, unsigned char* b, size_t len, size_t& lastEqualIndex)
{
	lastEqualIndex = 0;
	for (size_t i = 0; i < len; i++) {
		if (a[i] == b[i]) { lastEqualIndex++; }
		else {
			if (a[i] < b[i]) return 2; // _lt
			else return 4; // _gt
		}
	}
	return 1; // _equ
}

unsigned char XKeySearch2(unsigned char* xitem, unsigned char* xstring, unsigned short& iItem, size_t& iItemIndex, unsigned short nItems, unsigned short o, bool AfterEqu)
{
	/*
	 * !!!!!!!!!! POKUD o = 3 !!!!!!!!!!!
	 * struktura indexoveho zaznamu:
	 * 2 B - WORD - cislo zaznamu v .000
	 * 1 B - BYTE - ? (mozna oznaceni plastnosti zaznamu: 0 - platny, 1 - neplatny) ?
	 * 1 B - BYTE - pozice predchoziho zaznamu, od ktere dochazi ke zmene hodnoty
	 * 1 B - BYTE - delka dat, ktera nasleduji
	 * x B - DATA
	 */
	if (!(o == 3 || o == 7)) throw std::exception("Exception: XKeySearch2() 'o' not 3 or 7 !!!");
	iItem = 1;

	unsigned char actItem[256]{ 0 };
	unsigned char strLen = xstring[0];
	size_t lastEqualIndex = 0; // pocet znaku, ktere jsou od zacatku stejne, pokud je pri pristim pruchodu mensi, vracime _lt
	
	size_t inputIndex = 0;
	while (iItem <= nItems) {
		iItemIndex = inputIndex;
		// cislo zaznamu tady nepotrebujeme
		// iItem = *(unsigned short*)&xitem[inputIndex]; // cislo zaznamu v .000
		inputIndex += o;
		unsigned char from = xitem[inputIndex++];  // zmena predchoziho od pozice FROM
		unsigned char ixLen = xitem[inputIndex++]; // delka zaznamu v indexu
		memcpy(&actItem[from], &xitem[inputIndex], ixLen);
		if (ixLen + from == strLen) {
			// delka indexu je stejna jako delka hledaneho retezce
			auto prevLastEqualIndex = lastEqualIndex;
			auto cmp = cmpstr(actItem, &xstring[1], strLen, lastEqualIndex);
			if (cmp == 1) return 1; // _equ
			if (lastEqualIndex < prevLastEqualIndex || cmp == 4) {
				// jsme na polozce, ktera je za hledanym vyrazem - _gt
				// nebo jsme na polozce, ktera ma horsi shodu nez predchozi
				return (unsigned char)cmp;
			}
		}
		inputIndex += ixLen;
		iItem++;
	}
	return 0;
}

unsigned char XKeySearch(unsigned char* xitem, unsigned char* xstring, unsigned short& iItem, unsigned short nItems, unsigned short o, bool AfterEqu)
{
	InitR();
	BX = 0; // v ES:BX je adresa XItem
	iItem = 1;
	DX = 1;
label1:
	BX += o;
	AX = 0;
	*AL = xitem[BX];
	if (DX <= AX) goto label5;
	DX = AX;
	SI = 0; // v DS:SI je xstring
	AX = 0;
	*AL = xstring[SI]; // delka stringu
	SI++;
	AX -= DX;
	SI += DX;
	*AH = xitem[BX + 1];
	DI = BX + 2;
	CX = 0;
	*CL = *AH;
	if (*AH <= *AL) goto label2;
	*CL = *AL;
label2:
	DX += CX;
	*CH = 0;
	for (size_t i = 0; i < CX; i++) {
		if (xstring[SI] == xitem[DI]) { SI++; DI++; continue; }
		if (xstring[SI] < xitem[DI]) goto label8;
		else goto label4;
	}
	if (*AL < *AH) goto label8;
	if (*AL > * AH) goto label3;
	if (AfterEqu == 0) goto label7;
label3:
	DX++;
label4:
	DX -= CX;
label5:
	AX = iItem;
	if (AX == nItems) goto label6;
	AX++;
	iItem = AX; AX = 0;
	*AL = xitem[BX + 1];
	AX += 2; BX += AX;
	goto label1;
label6:
	*AL = 4; // _gt
	iItem++;
	goto label9;
label7:
	*AL = 1; // _equ
	goto label9;
label8:
	*AL = 2; // _lt
label9:
	BX -= o;
	*(unsigned short*)xitem = BX;
	return *AL;
}

void XStringStoreA(pstring* str, unsigned char* A, unsigned short Len, bool CompLex, bool Descend)
{
	unsigned char V[256]{ 0 };
	DI = 0; // v DI je index V
	CX = Len;
	if (CompLex != false) goto label1;
	SI = 0; // DS:SI je A
	// v AX je segment zasobniku
	// v ES je segment zasobniku
	AX = CX;
	// TODO: presuneme A na zasobnik

	goto label2;
label1:
	SI = 0; // V ES:SI je A
	SI--;
	DX = 0;
	//call TranslateOrd();
label2:
	SI = AX;
label3:
	if (SI == 0) goto label4;
	if (V[SI] != 0x20) goto label4;
	SI--;
	goto label3;
label4:
	if (SI == AX) goto label5;
	SI++;
	V[SI] = 0x1F;
label5:
	CX = SI;
	DI = 0; // v ES:DI je objekt XString
	*BH = 0;
	*BL = (*str)[DI];
	*AL = *BL;
	*AL += *CL;
	if (*AL < *BL) goto label6;
	str[DI] = *AL;
	DI++;
	DI += BX;
	SI = 1;
	for (size_t i = 0; i < CX; i++) {
		(*str)[DI] = A[SI];
		SI++; DI++;
	}
	if (Descend == false) goto label6;
	// call NegateESDI;
label6:
	return;
}
