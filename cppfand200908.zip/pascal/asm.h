#pragma once
#include "../cppfand/pstring.h"

unsigned char XKeySearch(unsigned char* xitem, unsigned char* xstring, unsigned short& iItem, unsigned short nItems, unsigned short o, bool AfterEqu);
unsigned char XKeySearch2(unsigned char* xitem, unsigned char* xstring, unsigned short& iItem, size_t& iItemIndex, unsigned short nItems, unsigned short o, bool AfterEqu);
void XStringStoreA(pstring* str, unsigned char* A, unsigned short Len, bool CompLex, bool Descend);
int cmpstr(unsigned char* a, unsigned char* b, size_t len, size_t& lastEqualIndex);
